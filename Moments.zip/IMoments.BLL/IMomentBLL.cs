﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.BLL
{
    public interface IMomentBLL
    {
        MOMENT SaveMoment(MOMENT vobj_moment);
        MOMENT UpdateMoment(MOMENT vobj_moment);
        List<MOMENT> GetListMoment(int idmoment);
        MOMENT DeleteMoment(int idmoment);
    }
}
