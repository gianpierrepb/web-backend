﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.BLL
{
    public interface ICommentBLL
    {
        COMMENT SaveComment(COMMENT vobj_comment);
        COMMENT UpdateComment(COMMENT vobj_comment);
        List<COMMENT> GetListComment(int idcomment);
        COMMENT DeleteComment(int idcomment);
    }
}
