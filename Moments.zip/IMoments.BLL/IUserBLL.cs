﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.BLL
{
    public interface IUserBLL
    {
        USER app_LoginClient(USER vobj_user);
        USER app_ValidaToken(string pistr_tokensession);


        USER SaveUser(USER vobj_user);
        USER UpdateUser(USER vobj_user);
        List<USER> GetListUser(int iduser);
        USER DeleteUser(int iduser);

        List<USER> GetUserProfile(int pro_id);
        Task<List<USER>> GetUserProfileAsync(int pro_id);
        USER PostSaveUserProfile(USER vobj_user);
    }
}
