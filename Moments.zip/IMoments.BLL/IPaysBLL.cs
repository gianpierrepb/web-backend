﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.BLL
{
    public interface IPaysBLL
    {
        PAYS SavePays(PAYS vobj_pays);
        PAYS UpdatePays(PAYS vobj_pays);
        List<PAYS> GetListPays(int idpays);
        PAYS DeletePays(int idpays);
    }
}
