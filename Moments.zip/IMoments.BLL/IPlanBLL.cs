﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.BLL
{
    public interface IPlanBLL
    {
        PLAN SavePlan(PLAN vobj_plan);
        PLAN UpdatePlan(PLAN vobj_plan);
        List<PLAN> GetListPlan(int idplan);
        PLAN DeletePlan(int idplan);
    }
}
