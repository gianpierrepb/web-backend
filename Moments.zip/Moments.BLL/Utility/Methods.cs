﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.SessionState;

namespace Moments.BLL.Utility
{
    public class Methods
    {
        public static string mastr_GenerateTokenSession()
        {
            SessionIDManager vobj_SessionIDManager = new SessionIDManager();
            System.Web.HttpContext vobj_CurrentContext = System.Web.HttpContext.Current;
            string vstr_NewID = vobj_SessionIDManager.CreateSessionID(vobj_CurrentContext);
            bool vbol_Redirected = false;
            bool vbol_IsAdded = false;
            vobj_SessionIDManager.SaveSessionID(vobj_CurrentContext, vstr_NewID, out vbol_Redirected, out vbol_IsAdded);
            return vstr_NewID;
        }
    }
}
