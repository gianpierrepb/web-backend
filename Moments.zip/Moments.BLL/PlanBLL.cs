﻿using IMoments.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moments.ENT;
using IMoments.DAL;
using Moments.BLL.Utility;

namespace Moments.BLL
{
    public class PlanBLL : IPlanBLL
    {
        private IPlanDAL _iplandal;
        public PlanBLL(IPlanDAL iplandal)
        {
            _iplandal = iplandal;
        }

        #region CRUD
        public PLAN SavePlan(PLAN vobj_plan)
        {
            return _iplandal.SavePlan(vobj_plan);
        }
        public PLAN UpdatePlan(PLAN vobj_plan)
        {
            return _iplandal.UpdatePlan(vobj_plan);
        }

        public List<PLAN> GetListPlan(int idplan)
        {
            return _iplandal.GetListPlan(idplan);
        }
        public PLAN DeletePlan(int idplan)
        {
            return _iplandal.DeletePlan(idplan);
        }
        #endregion

    }
}
