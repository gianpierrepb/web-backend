﻿using IMoments.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moments.ENT;
using IMoments.DAL;
using Moments.BLL.Utility;

namespace Moments.BLL
{
    public class UserBLL : IUserBLL
    {
        private IUserDAL _iuserdal;
        public UserBLL(IUserDAL iuserdal)
        {
            _iuserdal = iuserdal;
        }

        public USER app_LoginClient(USER vobj_user)
        {
            //vobj_user.adm_device.DEV_TOKENSESSION = String.IsNullOrEmpty(vobj_user.adm_device.DEV_TOKENSESSION) ? Methods.mastr_GenerateTokenSession() : vobj_user.adm_device.DEV_TOKENSESSION;
            return _iuserdal.app_LoginClient(vobj_user);
        }

        public USER app_ValidaToken(string pistr_tokensession)
        {
            return _iuserdal.app_ValidaToken(pistr_tokensession);
        }


        #region CRUD
        public USER SaveUser(USER vobj_user)
        {
            return _iuserdal.SaveUser(vobj_user);
        }
        public USER UpdateUser(USER vobj_user)
        {
            return _iuserdal.UpdateUser(vobj_user);
        }

        public List<USER> GetListUser(int iduser)
        {
            return _iuserdal.GetListUser(iduser);
        }
        public USER DeleteUser(int iduser)
        {
            return _iuserdal.DeleteUser(iduser);
        }
        #endregion

        public List<USER> GetUserProfile(int pro_id)
        {
            return _iuserdal.GetUserProfile(pro_id);
        }

        public async Task<List<USER>> GetUserProfileAsync(int pro_id)
        {
            return await _iuserdal.GetUserProfileAsync(pro_id);
        }


        public USER PostSaveUserProfile(USER vobj_user)
        {
            return _iuserdal.PostSaveUserProfile(vobj_user);
        }
    }
}
