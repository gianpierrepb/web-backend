﻿using IMoments.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moments.ENT;
using IMoments.DAL;
using Moments.BLL.Utility;

namespace Moments.BLL
{
    public class CommentBLL : ICommentBLL
    {
        private ICommentDAL _icommentdal;
        public CommentBLL(ICommentDAL icommentdal)
        {
            _icommentdal = icommentdal;
        }

        #region CRUD
        public COMMENT SaveComment(COMMENT vobj_comment)
        {
            return _icommentdal.SaveComment(vobj_comment);
        }
        public COMMENT UpdateComment(COMMENT vobj_comment)
        {
            return _icommentdal.UpdateComment(vobj_comment);
        }

        public List<COMMENT> GetListComment(int idcomment)
        {
            return _icommentdal.GetListComment(idcomment);
        }
        public COMMENT DeleteComment(int idcomment)
        {
            return _icommentdal.DeleteComment(idcomment);
        }
        #endregion

    }
}
