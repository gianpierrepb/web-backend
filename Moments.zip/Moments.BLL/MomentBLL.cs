﻿using IMoments.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moments.ENT;
using IMoments.DAL;
using Moments.BLL.Utility;

namespace Moments.BLL
{
    public class MomentBLL : IMomentBLL
    {
        private IMomentDAL _imomentdal;
        public MomentBLL(IMomentDAL imomentdal)
        {
            _imomentdal = imomentdal;
        }

        #region CRUD
        public MOMENT SaveMoment(MOMENT vobj_moment)
        {
            return _imomentdal.SaveMoment(vobj_moment);
        }
        public MOMENT UpdateMoment(MOMENT vobj_moment)
        {
            return _imomentdal.UpdateMoment(vobj_moment);
        }

        public List<MOMENT> GetListMoment(int idmoment)
        {
            return _imomentdal.GetListMoment(idmoment);
        }
        public MOMENT DeleteMoment(int idmoment)
        {
            return _imomentdal.DeleteMoment(idmoment);
        }
        #endregion

    }
}
