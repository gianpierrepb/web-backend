﻿using IMoments.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moments.ENT;
using IMoments.DAL;
using Moments.BLL.Utility;

namespace Moments.BLL
{
    public class PhotoBLL : IPhotoBLL
    {
        private IPhotoDAL _iphotodal;
        public PhotoBLL(IPhotoDAL iphotodal)
        {
            _iphotodal = iphotodal;
        }

        #region CRUD
        public PHOTO SavePhoto(PHOTO vobj_photo)
        {
            return _iphotodal.SavePhoto(vobj_photo);
        }
        public PHOTO UpdatePhoto(PHOTO vobj_photo)
        {
            return _iphotodal.UpdatePhoto(vobj_photo);
        }

        public List<PHOTO> GetListPhoto(int idphoto)
        {
            return _iphotodal.GetListPhoto(idphoto);
        }
        public PHOTO DeletePhoto(int idphoto)
        {
            return _iphotodal.DeletePhoto(idphoto);
        }
        #endregion

    }
}
