﻿using IMoments.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moments.ENT;
using IMoments.DAL;
using Moments.BLL.Utility;

namespace Moments.BLL
{
    public class PaysBLL : IPaysBLL
    {
        private IPaysDAL _ipaysdal;
        public PaysBLL(IPaysDAL ipaysdal)
        {
            _ipaysdal = ipaysdal;
        }

        #region CRUD
        public PAYS SavePays(PAYS vobj_pays)
        {
            return _ipaysdal.SavePays(vobj_pays);
        }
        public PAYS UpdatePays(PAYS vobj_pays)
        {
            return _ipaysdal.UpdatePays(vobj_pays);
        }

        public List<PAYS> GetListPays(int idpays)
        {
            return _ipaysdal.GetListPays(idpays);
        }
        public PAYS DeletePays(int idpays)
        {
            return _ipaysdal.DeletePays(idpays);
        }
        #endregion

    }
}
