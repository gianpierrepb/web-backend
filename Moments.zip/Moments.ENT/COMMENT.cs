﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moments.ENT
{
    public class COMMENT
    {
        public int idcomment { get; set; }
        public int idmoment { get; set; }
        public int iduser { get; set; }
        public string text { get; set; }
        public DateTime create_at { get; set; }
        public DateTime update_at { get; set; }
        public string MSG { get; set; }

    }

}
