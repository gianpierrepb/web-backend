﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moments.ENT
{
    public class USER
    {
        public int iduser { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string phoneNumber { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public string email { get; set; }

        public string MSG { get; set; }
        //public DateTime AUD_REGISTEREDDATE { get; set; }
        //public DateTime AUD_LASTCHANGED { get; set; }
        public string profilepic { get; set; }
        //public List<ADM_REPORT> List_Report { get; set; }
    }

}
