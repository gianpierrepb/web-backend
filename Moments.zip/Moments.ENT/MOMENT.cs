﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moments.ENT
{
    public class MOMENT
    {
        public int idmoment { get; set; }
        public int iduser { get; set; }
        public string location { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string image { get; set; }
        public int deleted { get; set; }
        public DateTime create_at { get; set; }
        public DateTime update_at { get; set; }
        public DateTime duration { get; set; }

        public string MSG { get; set; }
        //public DateTime AUD_LASTCHANGED { get; set; }

    }

}
