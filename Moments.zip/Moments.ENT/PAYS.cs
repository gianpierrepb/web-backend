﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moments.ENT
{
    public class PAYS
    {
        public int idpays { get; set; }
        public int idplan { get; set; }
        public int iduser { get; set; }
        public string MSG { get; set; }
        public DateTime create_at { get; set; }
        //public DateTime AUD_LASTCHANGED { get; set; }

    }

}
