﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moments.ENT
{
    public class PHOTO
    {
        public int idphoto { get; set; }
        public int idmoment { get; set; }
        public string url { get; set; }
        public string path { get; set; }
        public string MSG { get; set; }

    }

}
