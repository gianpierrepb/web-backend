using IMoments.BLL;
using IMoments.DAL;
using Microsoft.Practices.Unity;
using Moments.BLL;
using Moments.DAL;
using System.Web.Http;
using Unity.WebApi;

namespace Moments.WS
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            container.RegisterType<IUserDAL, UserDAL>();
            container.RegisterType<IUserBLL, UserBLL>();

            //container.RegisterType<ITareoDAL, TareoDAL>();
            //container.RegisterType<ITareoBLL, TareoBLL>();

            //container.RegisterType<IContratoDAL, ContratoDAL>();
            //container.RegisterType<IContratoBLL, ContratoBLL>();

            //container.RegisterType<ICompaniaDAL, CompaniaDAL>();
            //container.RegisterType<ICompaniaBLL, CompaniaBLL>();

            //container.RegisterType<IReporteDAL, ReporteDAL>();
            //container.RegisterType<IReporteBLL, ReporteBLL>();

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}