﻿using IMoments.BLL;
using log4net;
using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Moments.WS.Areas.WebClient
{
    //[Route("api/[controller]")]
    public class ADM_USERController : ApiController
    {
        private IUserBLL _usrbll;
        ILog log = log4net.LogManager.GetLogger(typeof(ADM_USERController));

        public ADM_USERController(IUserBLL usrbll)
        {
            _usrbll = usrbll;
        }


        public USER PostLoginClient(USER vobj_user)
        {
            try
            {
                return _usrbll.app_LoginClient(vobj_user);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }

        public USER GetValidaToken(string pistr_tokensession)
        {
            try
            {
                return _usrbll.app_ValidaToken(pistr_tokensession);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #region CRUD

        public USER SaveUser(USER vobj_user)
        {
            try
            {
                return _usrbll.SaveUser(vobj_user);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public USER UpdateUser(USER vobj_user)
        {
            try
            {
                return _usrbll.UpdateUser(vobj_user);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public List<USER> GetListUser(int iduser)
        {
            try
            {
                return _usrbll.GetListUser(iduser);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public USER DeleteUser(int iduser)
        {
            try
            {
                return _usrbll.DeleteUser(iduser);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #endregion


        public USER PostSaveUserProfile(USER vobj_user)
        {
            try
            {
                return _usrbll.PostSaveUserProfile(vobj_user);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }

    }
}
