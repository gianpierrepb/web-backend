﻿using IMoments.BLL;
using log4net;
using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Moments.WS.Areas.WebClient
{
    //[Route("api/[controller]")]
    public class ADM_MOMENTController : ApiController
    {
        private IMomentBLL _momentbll;
        ILog log = log4net.LogManager.GetLogger(typeof(ADM_MOMENTController));

        public ADM_MOMENTController(IMomentBLL momentbll)
        {
            _momentbll = momentbll;
        }


        #region CRUD

        public MOMENT SaveMoment(MOMENT vobj_moment)
        {
            try
            {
                return _momentbll.SaveMoment(vobj_moment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public MOMENT UpdateMoment(MOMENT vobj_moment)
        {
            try
            {
                return _momentbll.UpdateMoment(vobj_moment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public List<MOMENT> GetListMoment(int idmoment)
        {
            try
            {
                return _momentbll.GetListMoment(idmoment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public MOMENT DeleteMoment(int idmoment)
        {
            try
            {
                return _momentbll.DeleteMoment(idmoment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #endregion



    }
}
