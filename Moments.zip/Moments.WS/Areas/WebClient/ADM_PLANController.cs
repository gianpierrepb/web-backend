﻿using IMoments.BLL;
using log4net;
using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Moments.WS.Areas.WebClient
{
    //[Route("api/[controller]")]
    public class ADM_PLANController : ApiController
    {
        private IPlanBLL _planbll;
        ILog log = log4net.LogManager.GetLogger(typeof(ADM_PLANController));

        public ADM_PLANController(IPlanBLL planbll)
        {
            _planbll = planbll;
        }


        #region CRUD

        public PLAN SavePlan(PLAN vobj_plan)
        {
            try
            {
                return _planbll.SavePlan(vobj_plan);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public PLAN UpdatePlan(PLAN vobj_plan)
        {
            try
            {
                return _planbll.UpdatePlan(vobj_plan);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public List<PLAN> GetListPlan(int idplan)
        {
            try
            {
                return _planbll.GetListPlan(idplan);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public PLAN DeletePlan(int idplan)
        {
            try
            {
                return _planbll.DeletePlan(idplan);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #endregion



    }
}
