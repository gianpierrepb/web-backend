﻿using IMoments.BLL;
using log4net;
using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Moments.WS.Areas.WebClient
{
    //[Route("api/[controller]")]
    public class ADM_PHOTOController : ApiController
    {
        private IPhotoBLL _photobll;
        ILog log = log4net.LogManager.GetLogger(typeof(ADM_PHOTOController));

        public ADM_PHOTOController(IPhotoBLL photobll)
        {
            _photobll = photobll;
        }


        #region CRUD

        public PHOTO SavePhoto(PHOTO vobj_photo)
        {
            try
            {
                return _photobll.SavePhoto(vobj_photo);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public PHOTO UpdatePhoto(PHOTO vobj_photo)
        {
            try
            {
                return _photobll.UpdatePhoto(vobj_photo);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public List<PHOTO> GetListPhoto(int idphoto)
        {
            try
            {
                return _photobll.GetListPhoto(idphoto);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public PHOTO DeletePhoto(int idphoto)
        {
            try
            {
                return _photobll.DeletePhoto(idphoto);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #endregion



    }
}
