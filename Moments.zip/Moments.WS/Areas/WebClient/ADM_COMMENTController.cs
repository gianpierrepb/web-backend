﻿using IMoments.BLL;
using log4net;
using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Moments.WS.Areas.WebClient
{
    //[Route("api/[controller]")]
    public class ADM_COMMENTController : ApiController
    {
        private ICommentBLL _commentbll;
        ILog log = log4net.LogManager.GetLogger(typeof(ADM_COMMENTController));

        public ADM_COMMENTController(ICommentBLL commentbll)
        {
            _commentbll = commentbll;
        }


        #region CRUD

        public COMMENT SaveComment(COMMENT vobj_comment)
        {
            try
            {
                return _commentbll.SaveComment(vobj_comment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public COMMENT UpdateComment(COMMENT vobj_comment)
        {
            try
            {
                return _commentbll.UpdateComment(vobj_comment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public List<COMMENT> GetListComment(int idcomment)
        {
            try
            {
                return _commentbll.GetListComment(idcomment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public COMMENT DeleteComment(int idcomment)
        {
            try
            {
                return _commentbll.DeleteComment(idcomment);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #endregion



    }
}
