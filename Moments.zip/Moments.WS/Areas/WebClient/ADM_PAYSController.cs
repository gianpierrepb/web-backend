﻿using IMoments.BLL;
using log4net;
using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Moments.WS.Areas.WebClient
{
    //[Route("api/[controller]")]
    public class ADM_PAYSController : ApiController
    {
        private IPaysBLL _paysbll;
        ILog log = log4net.LogManager.GetLogger(typeof(ADM_PAYSController));

        public ADM_PAYSController(IPaysBLL paysbll)
        {
            _paysbll = paysbll;
        }


        #region CRUD

        public PAYS SavePays(PAYS vobj_pays)
        {
            try
            {
                return _paysbll.SavePays(vobj_pays);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public PAYS UpdatePays(PAYS vobj_pays)
        {
            try
            {
                return _paysbll.UpdatePays(vobj_pays);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public List<PAYS> GetListPays(int idpays)
        {
            try
            {
                return _paysbll.GetListPays(idpays);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
        public PAYS DeletePays(int idpays)
        {
            try
            {
                return _paysbll.DeletePays(idpays);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }


        #endregion



    }
}
