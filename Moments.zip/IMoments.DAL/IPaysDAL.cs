﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.DAL
{
    public interface IPaysDAL
    {
        PAYS SavePays(PAYS vobj_pays);
        PAYS UpdatePays(PAYS vobj_pays);
        List<PAYS> GetListPays(int idpays);
        PAYS DeletePays(int idpays);
    }
}
