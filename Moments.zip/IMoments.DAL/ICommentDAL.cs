﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.DAL
{
    public interface ICommentDAL
    {
        COMMENT SaveComment(COMMENT vobj_comment);
        COMMENT UpdateComment(COMMENT vobj_comment);
        List<COMMENT> GetListComment(int idcomment);
        COMMENT DeleteComment(int idcomment);
    }
}
