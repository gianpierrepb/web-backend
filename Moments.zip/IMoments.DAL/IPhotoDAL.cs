﻿using Moments.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMoments.DAL
{
    public interface IPhotoDAL
    {
        PHOTO SavePhoto(PHOTO vobj_photo);
        PHOTO UpdatePhoto(PHOTO vobj_photo);
        List<PHOTO> GetListPhoto(int idphoto);
        PHOTO DeletePhoto(int idphoto);
    }
}
