﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using Moments.DAL.Common;
using Moments.DAL;
using IMoments.DAL;
using Moments.ENT;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Moments.DAL
{
    public class PhotoDAL : RepositoryBase, IPhotoDAL
    {

        #region CRUD

        public PHOTO SavePhoto(PHOTO vobj_photo)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idphoto", 0);
                parametros.Add("@idmoment", vobj_photo.idmoment);
                parametros.Add("@url", vobj_photo.url);
                parametros.Add("@path", vobj_photo.path);

                parametros.Add("@tipo", 1);

                vobj_photo.MSG = cnn.Execute("ADM_CRUD_PHOTO", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }

            return vobj_photo;
        }
        public PHOTO UpdatePhoto(PHOTO vobj_photo)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();

                parametros.Add("@idphoto", vobj_photo.idphoto);
                parametros.Add("@idmoment", vobj_photo.idmoment);
                parametros.Add("@url", vobj_photo.url);
                parametros.Add("@path", vobj_photo.path);
                parametros.Add("@tipo", 2);

                vobj_photo.MSG = cnn.Execute("ADM_CRUD_PHOTO", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_photo;
        }

        public List<PHOTO> GetListPhoto(int idphoto)
        {
            List<PHOTO> vlist_user = new List<PHOTO>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@idphoto", idphoto);
                parametros.Add("@idmoment", "");
                parametros.Add("@url", "");
                parametros.Add("@path", "");
                parametros.Add("@tipo", 3);
                vlist_user = cnn.Query<PHOTO>("ADM_CRUD_PHOTO", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }
        public PHOTO DeletePhoto(int idphoto)
        {
            PHOTO vobj_photo = new PHOTO();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idphoto", idphoto);
                parametros.Add("@idmoment", "");
                parametros.Add("@url", "");
                parametros.Add("@path", "");
                parametros.Add("@tipo", 4);

                vobj_photo.MSG = cnn.Execute("ADM_CRUD_PHOTO", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_photo;
        }

        #endregion

    }
}
