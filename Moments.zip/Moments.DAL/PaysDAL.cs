﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using Moments.DAL.Common;
using Moments.DAL;
using IMoments.DAL;
using Moments.ENT;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Moments.DAL
{
    public class PaysDAL : RepositoryBase, IPaysDAL
    {

        #region CRUD

        public PAYS SavePays(PAYS vobj_pays)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idpays", 0);
                parametros.Add("@idplan", vobj_pays.idplan);
                parametros.Add("@iduser", vobj_pays.iduser);
                parametros.Add("@tipo", 1);

                vobj_pays.MSG = cnn.Execute("ADM_CRUD_PAYS", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }

            return vobj_pays;
        }
        public PAYS UpdatePays(PAYS vobj_pays)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();

                parametros.Add("@idpays", vobj_pays.idpays);
                parametros.Add("@idplan", vobj_pays.idplan);
                parametros.Add("@iduser", vobj_pays.iduser);
                parametros.Add("@tipo", 2);

                vobj_pays.MSG = cnn.Execute("ADM_CRUD_PAYS", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_pays;
        }

        public List<PAYS> GetListPays(int idpays)
        {
            List<PAYS> vlist_user = new List<PAYS>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@idpays", idpays);
                parametros.Add("@idplan", "");
                parametros.Add("@iduser", "");
                parametros.Add("@tipo", 3);
                vlist_user = cnn.Query<PAYS>("ADM_CRUD_PAYS", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }
        public PAYS DeletePays(int idpays)
        {
            PAYS vobj_pays = new PAYS();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idpays", idpays);
                parametros.Add("@idplan", "");
                parametros.Add("@iduser", "");
                parametros.Add("@tipo", 4);

                vobj_pays.MSG = cnn.Execute("ADM_CRUD_PAYS", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_pays;
        }

        #endregion

    }
}
