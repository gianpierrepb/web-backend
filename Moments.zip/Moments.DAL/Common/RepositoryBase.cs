﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Moments.DAL.Common
{
    public abstract class RepositoryBase
    {
        protected IDbConnection Connection
        {
            get 
            {
                return new SqlConnection(ConfigurationManager.ConnectionStrings["HorasSSEE"].ConnectionString);   
            }
        }
    }
}
