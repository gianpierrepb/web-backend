﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using Moments.DAL.Common;
using Moments.DAL;
using IMoments.DAL;
using Moments.ENT;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Moments.DAL
{
    public class PlanDAL : RepositoryBase, IPlanDAL
    {

        #region CRUD

        public PLAN SavePlan(PLAN vobj_plan)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idplan", 0);
                parametros.Add("@description", vobj_plan.description);
                parametros.Add("@price", vobj_plan.price);
                parametros.Add("@tipo", 1);

                vobj_plan.MSG = cnn.Execute("ADM_CRUD_PLAN", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }

            return vobj_plan;
        }
        public PLAN UpdatePlan(PLAN vobj_plan)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();

                parametros.Add("@idplan", vobj_plan.idplan);
                parametros.Add("@description", vobj_plan.description);
                parametros.Add("@price", vobj_plan.price);
                parametros.Add("@tipo", 2);

                vobj_plan.MSG = cnn.Execute("ADM_CRUD_PLAN", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_plan;
        }

        public List<PLAN> GetListPlan(int idplan)
        {
            List<PLAN> vlist_user = new List<PLAN>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@idplan", idplan);
                parametros.Add("@description", "");
                parametros.Add("@price", "");
                parametros.Add("@tipo", 3);
                vlist_user = cnn.Query<PLAN>("ADM_CRUD_PLAN", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }
        public PLAN DeletePlan(int idplan)
        {
            PLAN vobj_plan = new PLAN();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idplan", idplan);
                parametros.Add("@description", "");
                parametros.Add("@price", "");
                parametros.Add("@tipo", 4);

                vobj_plan.MSG = cnn.Execute("ADM_CRUD_PLAN", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_plan;
        }

        #endregion

    }
}
