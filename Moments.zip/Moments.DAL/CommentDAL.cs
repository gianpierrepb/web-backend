﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using Moments.DAL.Common;
using Moments.DAL;
using IMoments.DAL;
using Moments.ENT;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Moments.DAL
{
    public class CommentDAL : RepositoryBase, ICommentDAL
    {

        #region CRUD

        public COMMENT SaveComment(COMMENT vobj_comment)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idcomment", 0);
                parametros.Add("@idmoment", vobj_comment.idmoment);
                parametros.Add("@iduser", vobj_comment.iduser);
                parametros.Add("@text", vobj_comment.text);
                parametros.Add("@tipo", 1);

                vobj_comment.MSG = cnn.Execute("ADM_CRUD_COMMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }

            return vobj_comment;
        }
        public COMMENT UpdateComment(COMMENT vobj_comment)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();

                parametros.Add("@idcomment", vobj_comment.idcomment);
                parametros.Add("@idmoment", vobj_comment.idmoment);
                parametros.Add("@iduser", vobj_comment.iduser);
                parametros.Add("@text", vobj_comment.text);
                parametros.Add("@tipo", 2);

                vobj_comment.MSG = cnn.Execute("ADM_CRUD_COMMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_comment;
        }

        public List<COMMENT> GetListComment(int idcomment)
        {
            List<COMMENT> vlist_user = new List<COMMENT>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@idcomment", idcomment);
                parametros.Add("@idmoment", "");
                parametros.Add("@iduser", "");
                parametros.Add("@text", "");
                parametros.Add("@tipo", 3);
                vlist_user = cnn.Query<COMMENT>("ADM_CRUD_COMMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }
        public COMMENT DeleteComment(int idcomment)
        {
            COMMENT vobj_comment = new COMMENT();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idcomment", idcomment);
                parametros.Add("@idmoment", "");
                parametros.Add("@iduser", "");
                parametros.Add("@text", "");
                parametros.Add("@tipo", 4);

                vobj_comment.MSG = cnn.Execute("ADM_CRUD_COMMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_comment;
        }

        #endregion

    }
}
