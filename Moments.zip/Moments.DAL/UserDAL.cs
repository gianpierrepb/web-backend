﻿using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using Moments.DAL.Common;
using Moments.DAL;
using IMoments.DAL;
using Moments.ENT;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Moments.DAL
{
    public class UserDAL : RepositoryBase, IUserDAL
    {

        public USER app_LoginClient(USER vobj_user)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                //parametros.Add("@usr_id", vobj_user.USR_ID);
                //parametros.Add("@usr_password", vobj_user.USR_PASSWORD);

                using (var multi = cnn.QueryMultiple("ADM_GetUserByEmailAndPassword", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure))
                {
                    vobj_user = multi.ReadSingle<USER>();
                }
            }
            
            return vobj_user;
        }

        public USER app_ValidaToken(string pistr_tokensession)
        {
            USER vobj_user = new USER();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@dev_tokensession", pistr_tokensession);

                vobj_user=cnn.QueryFirst<USER>("ADM_GetDeviceByTokenSession", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure);
            }

            return vobj_user;
        }

        #region CRUD

        public USER SaveUser(USER vobj_user)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@iduser", 0);
                parametros.Add("@name", vobj_user.Name);
                parametros.Add("@lastname", vobj_user.LastName);
                parametros.Add("@email", vobj_user.email);
                parametros.Add("@username", vobj_user.userName);
                parametros.Add("@password", vobj_user.password);
                parametros.Add("@phonenumber", vobj_user.phoneNumber);
                parametros.Add("@tipo", 1);

                vobj_user.MSG = cnn.Execute("ADM_CRUD_USER", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }

            return vobj_user;
        }
        public USER UpdateUser(USER vobj_user)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();

                parametros.Add("@iduser", vobj_user.iduser);
                parametros.Add("@name", vobj_user.Name);
                parametros.Add("@lastname", vobj_user.LastName);
                parametros.Add("@email", vobj_user.email);
                parametros.Add("@username", vobj_user.userName);
                parametros.Add("@password", vobj_user.password);
                parametros.Add("@phonenumber", vobj_user.phoneNumber);
                parametros.Add("@tipo", 2);

                vobj_user.MSG = cnn.Execute("ADM_CRUD_USER", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_user;
        }

        public List<USER> GetListUser(int iduser)
        {
            List<USER> vlist_user = new List<USER>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@iduser", iduser);
                parametros.Add("@name", "");
                parametros.Add("@lastname", "");
                parametros.Add("@email", "");
                parametros.Add("@username", "");
                parametros.Add("@password", "");
                parametros.Add("@phonenumber", "");
                parametros.Add("@tipo", 3);
                vlist_user = cnn.Query<USER>("ADM_CRUD_USER", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }
        public USER DeleteUser(int iduser)
        {
            USER vobj_user = new USER();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@iduser", iduser);
                parametros.Add("@name", "");
                parametros.Add("@lastname", "");
                parametros.Add("@email", "");
                parametros.Add("@username", "");
                parametros.Add("@password", "");
                parametros.Add("@phonenumber", "");
                parametros.Add("@tipo", 4);

                vobj_user.MSG = cnn.Execute("ADM_CRUD_USER", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_user;
        }

        #endregion

        public List<USER> GetUserProfile(int pro_id)
        {
            List<USER> vlist_user = new List<USER>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@pro_id", pro_id);
                vlist_user = cnn.Query<USER>("ADM_GetUserProfile", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }

        public async Task<List<USER>> GetUserProfileAsync(int pro_id)
        {
            List<USER> vlist_user = new List<USER>();
            using (SqlConnection cnn = new SqlConnection(Connection.ConnectionString))
            {
                await cnn.OpenAsync();

                var parametros = new DynamicParameters();
                parametros.Add("@pro_id", pro_id);
                var temp = await cnn.QueryAsync<USER>("ADM_GetUserProfile", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure);
                vlist_user = temp.ToList();
            }
            return vlist_user;
        }

        public USER PostSaveUserProfile(USER vobj_user)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                //parametros.Add("@usr_id", vobj_user.USR_ID);
                //parametros.Add("@usr_login", vobj_user.USR_LOGEADO);
                //parametros.Add("@pro_id", vobj_user.PRO_ID);

                vobj_user.MSG = cnn.Query<int>("ADM_PostSaveUserProfile", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).FirstOrDefault().ToString();
            }

            return vobj_user;
        }
    }
}
