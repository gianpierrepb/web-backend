﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using Moments.DAL.Common;
using Moments.DAL;
using IMoments.DAL;
using Moments.ENT;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Moments.DAL
{
    public class MomentDAL : RepositoryBase, IMomentDAL
    {

        #region CRUD

        public MOMENT SaveMoment(MOMENT vobj_moment)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idmoment", 0);
                parametros.Add("@iduser", vobj_moment.iduser);
                parametros.Add("@location", vobj_moment.location);
                parametros.Add("@title", vobj_moment.title);
                parametros.Add("@description", vobj_moment.description);
                parametros.Add("@image", vobj_moment.image);
                parametros.Add("@deleted", vobj_moment.deleted);
                parametros.Add("@duration", vobj_moment.duration);
                parametros.Add("@tipo", 1);

                vobj_moment.MSG = cnn.Execute("ADM_CRUD_MOMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }

            return vobj_moment;
        }
        public MOMENT UpdateMoment(MOMENT vobj_moment)
        {
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();

                parametros.Add("@idmoment", vobj_moment.idmoment);
                parametros.Add("@iduser", vobj_moment.iduser);
                parametros.Add("@location", vobj_moment.location);
                parametros.Add("@title", vobj_moment.title);
                parametros.Add("@description", vobj_moment.description);
                parametros.Add("@image", vobj_moment.image);
                parametros.Add("@deleted", vobj_moment.deleted);
                parametros.Add("@duration", vobj_moment.duration);
                parametros.Add("@tipo", 2);

                vobj_moment.MSG = cnn.Execute("ADM_CRUD_MOMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_moment;
        }

        public List<MOMENT> GetListMoment(int idmoment)
        {
            List<MOMENT> vlist_user = new List<MOMENT>();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();

                var parametros = new DynamicParameters();
                parametros.Add("@idmoment", idmoment);
                parametros.Add("@iduser", "");
                parametros.Add("@location", "");
                parametros.Add("@title", "");
                parametros.Add("@description", "");
                parametros.Add("@image", "");
                parametros.Add("@deleted", "");
                parametros.Add("@duration", "");
                parametros.Add("@tipo", 3);
                vlist_user = cnn.Query<MOMENT>("ADM_CRUD_MOMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return vlist_user;
        }
        public MOMENT DeleteMoment(int idmoment)
        {
            MOMENT vobj_moment = new MOMENT();
            using (IDbConnection cnn = Connection)
            {
                cnn.Open();
                var parametros = new DynamicParameters();
                parametros.Add("@idmoment", idmoment);
                parametros.Add("@iduser", "");
                parametros.Add("@location", "");
                parametros.Add("@title", "");
                parametros.Add("@description", "");
                parametros.Add("@image", "");
                parametros.Add("@deleted", "");
                parametros.Add("@duration", "");
                parametros.Add("@tipo", 4);

                vobj_moment.MSG = cnn.Execute("ADM_CRUD_MOMENT", parametros, commandTimeout: 300, commandType: System.Data.CommandType.StoredProcedure).ToString();
            }
            return vobj_moment;
        }

        #endregion

    }
}
